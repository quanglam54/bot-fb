// Cầu nối giữa trang web (bot-fb.netlify.app) và extension
document.documentElement.setAttribute('data-zeno-ext', chrome.runtime.getManifest().version);

const RELOAD_MSG = 'Extension vừa được cập nhật, tải lại trang (F5).';

window.addEventListener('message', (e) => {
  if (e.source !== window || !e.data || e.data.zeno !== 'req') return;
  const { id, type, payload } = e.data;
  const reply = (result, error) => window.postMessage({ zeno: 'res', id, result, error }, location.origin);

  // Extension đã được tải lại (↻) trong khi tab này còn mở -> cầu nối cũ hết hiệu lực, chỉ cần F5
  if (!chrome.runtime || !chrome.runtime.id) return reply(null, RELOAD_MSG);
  try {
    chrome.runtime.sendMessage({ type, payload }, (resp) => {
      const err = chrome.runtime.lastError;
      reply(resp && resp.result, err ? RELOAD_MSG : resp && resp.error);
    });
  } catch {
    reply(null, RELOAD_MSG);
  }
});
