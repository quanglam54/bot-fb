// Zeno Share Bot - chạy nền: lịch tự share, điều khiển tab Facebook, báo kết quả lên Supabase
importScripts('config.js', 'fbscripts.js');

const VERSION = chrome.runtime.getManifest().version;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rand = (a, b) => Math.floor(a + Math.random() * (b - a));
const ymd = (d = new Date()) => d.toLocaleDateString('sv-SE');

// auto + everyDays: tự share định kỳ (N ngày 1 bài); autoNew: tự share bài mới của page (~1 tiếng sau khi đăng)
// react: 'love' | 'like' | 'none'; comment: tự bình luận (mặc định tắt)
const DEFAULT_SETTINGS = { pages: DEFAULT_PAGES, auto: false, hour: 9, everyDays: 3, autoNew: false, react: 'love', comment: false };
const NEW_POST_DELAY = 60 * 60 * 1000;   // share bài mới sau khi phát hiện ~1 tiếng
const NEW_SCAN_EVERY = 60 * 60 * 1000;   // quét page tìm bài mới mỗi 1 tiếng (7h-23h)
const NEW_PER_DAY = 3;                   // tối đa 3 bài mới/ngày

function normalizeUrl(href) {
  try {
    const u = new URL(href.trim());
    if (!/(^|\.)facebook\.com$/.test(u.hostname)) return null;
    if (/permalink\.php|story\.php/.test(u.pathname)) {
      return `https://www.facebook.com${u.pathname}?story_fbid=${u.searchParams.get('story_fbid')}&id=${u.searchParams.get('id')}`;
    }
    return `https://www.facebook.com${u.pathname}`.replace(/\/$/, '');
  } catch { return null; }
}

// ---------- Lưu trữ ----------
const get = async (k, def) => (await chrome.storage.local.get(k))[k] ?? def;
const set = (k, v) => chrome.storage.local.set({ [k]: v });
const settings = async () => ({ ...DEFAULT_SETTINGS, ...(await get('settings', {})) });

async function patchState(p) {
  const s = await get('state', {});
  await set('state', { ...s, ...p });
}
async function log(msg) {
  const s = await get('state', {});
  const logs = [...(s.logs || []), `[${new Date().toLocaleTimeString('vi-VN')}] ${msg}`].slice(-60);
  await set('state', { ...s, logs });
}

// ---------- Supabase ----------
async function sb(pathname, { method = 'GET', body, token, headers = {} } = {}) {
  const res = await fetch(SB_URL + pathname, {
    method,
    headers: { apikey: SB_KEY, Authorization: `Bearer ${token || SB_KEY}`, 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const m = (data && (data.msg || data.message || data.error_description || data.error)) || `HTTP ${res.status}`;
    // Database chưa chạy setup4.sql (chưa có cột dấu vân tay) -> bỏ cột đó và thử lại theo cách cũ
    if (/(fp|post_fp)\b.*(does not exist|column)|column.*\b(fp|post_fp)\b/i.test(m) && !arguments[1]?._noFp) {
      const strip = (b) => (Array.isArray(b) ? b.map(strip) : b && typeof b === 'object'
        ? Object.fromEntries(Object.entries(b).filter(([k]) => k !== 'fp' && k !== 'post_fp')) : b);
      return sb(pathname.replace(/,post_fp|,fp\b/g, ''), { method, body: strip(body), token, headers, _noFp: true });
    }
    throw new Error(/Invalid login/i.test(m) ? 'Sai email hoặc mật khẩu.' : m);
  }
  return data;
}

async function saveSession(d) {
  const session = {
    access_token: d.access_token,
    refresh_token: d.refresh_token,
    expires_at: d.expires_at || Math.floor(Date.now() / 1000) + (d.expires_in || 3600),
    user: { id: d.user.id, email: d.user.email, name: d.user.user_metadata?.name || '' },
  };
  await set('session', session);
  return session;
}

async function session() {
  let s = await get('session', null);
  if (!s) throw new Error('Extension chưa kết nối tài khoản. Mở web và đăng nhập.');
  if (s.expires_at - 60 < Date.now() / 1000) {
    try {
      s = await saveSession(await sb('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: s.refresh_token } }));
    } catch (e) {
      await chrome.storage.local.remove('session');
      throw new Error('Phiên đăng nhập hết hạn. Mở web và kết nối lại extension.');
    }
  }
  return s;
}

// ---------- Tab Facebook ----------
function waitTab(tabId, timeout = 45000) {
  return new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(on); clearTimeout(t); resolve(); };
    const on = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const t = setTimeout(done, timeout);
    chrome.tabs.onUpdated.addListener(on);
  });
}

async function openFb(url, prev) {
  if (prev) {
    await chrome.tabs.update(prev.tabId, { url });
    await waitTab(prev.tabId);
    await sleep(rand(4000, 6500));
    return prev;
  }
  const win = await chrome.windows.create({ url, focused: false, width: 1100, height: 850, left: 40, top: 40 });
  const tabId = win.tabs[0].id;
  await waitTab(tabId);
  await sleep(rand(4000, 6500));
  return { windowId: win.id, tabId };
}

async function inTab(fb, func, args = []) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId: fb.tabId }, func, args, world: 'MAIN' });
  return r && r.result;
}

// ---------- Công việc chính ----------
let running = false;

// Quét các page, trả về link bài (mới nhất trước). Tài khoản admin thì đẩy luôn lên danh sách chung.
async function scanPages(s, cfg, fb, scrolls) {
  const urls = [], fps = {};
  for (const page of cfg.pages) {
    await log(`Quét page: ${page.replace('https://www.facebook.com/', '')}`);
    fb = await openFb(page, fb);
    // Đưa cửa sổ lên trước: FB chỉ gắn link bài khi trang đang được chọn
    await chrome.windows.update(fb.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(fb.tabId, { active: true }).catch(() => {});
    await sleep(800);
    const r = await inTab(fb, fbScan, [scrolls, page]);
    if (!r || !r.ok) throw Object.assign(new Error(fbError(r && r.code)), { code: r && r.code, fb });
    await log(`  -> ${r.urls.length} bài`);
    urls.push(...r.urls);
    Object.assign(fps, r.fps || {});
    if (r.urls.length) await pushPosts(s, r.urls, r.fps || {}, page);
  }
  return { urls, fps, fb };
}

// Đưa bài lên danh sách chung, bỏ bài đã có (cùng link HOẶC cùng dấu vân tay — FB hay đổi link của cùng 1 bài)
async function pushPosts(s, list, fps, page) {
  const existing = await sb('/rest/v1/posts?select=url,fp', { token: s.access_token }).catch(() => []);
  const haveUrl = new Set(existing.map((x) => x.url));
  const haveFp = new Set(existing.map((x) => x.fp).filter(Boolean));
  const rows = [...list].reverse() // cũ trước, mới sau -> trên web bài mới nhất nằm trên cùng
    .filter((url) => !haveUrl.has(url) && !(fps[url] && haveFp.has(fps[url])))
    .map((url) => ({ url, page_url: page, fp: fps[url] || null }));
  for (const row of rows) {
    await sb('/rest/v1/posts', { method: 'POST', token: s.access_token, headers: { Prefer: 'return=minimal' }, body: row })
      .catch((e) => log(`(Không đưa được bài lên danh sách chung: ${/row-level security/i.test(e.message) ? 'tài khoản chưa có quyền — admin cần chạy setup3.sql' : e.message})`));
  }
  // Bài cũ chưa có dấu vân tay -> bổ sung
  for (const x of existing) if (!x.fp && fps[x.url]) await setPostFp(s, x.url, fps[x.url]);
}

// Ghi dấu vân tay cho bài chưa có (hàm set_post_fp trong setup5.sql — thành viên nào cũng gọi được)
function setPostFp(s, url, fp) {
  if (!url || !fp) return Promise.resolve();
  return sb('/rest/v1/rpc/set_post_fp', { method: 'POST', token: s.access_token, body: { p_url: url, p_fp: fp } }).catch(() => {});
}

// Bài tôi đã share: theo link và theo dấu vân tay (gồm cả dấu vân tay của bài trong danh sách có link trùng lịch sử share)
async function mySharedSets(s) {
  const [mine, posts] = await Promise.all([
    sb(`/rest/v1/shares?select=post_url,post_fp&user_id=eq.${s.user.id}`, { token: s.access_token }),
    sb('/rest/v1/posts?select=url,fp', { token: s.access_token }).catch(() => []),
  ]);
  const urls = new Set(mine.map((x) => x.post_url));
  const fps = new Set(mine.map((x) => x.post_fp).filter(Boolean));
  for (const p of posts) if (p.fp && urls.has(p.url)) fps.add(p.fp);
  return { urls, fps, has: (url, fp) => urls.has(url) || (!!fp && fps.has(fp)) };
}

const REASON = { daily: 'Bắt đầu lượt tự share định kỳ', new: 'Share bài mới của page', link: 'Share bài theo link đã dán', queue: 'Share hàng loạt' };

async function runJob({ url = null, reason = '' } = {}) {
  if (running) throw new Error('Bot đang chạy, đợi xong lượt này.');
  running = true;
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  await patchState({ running: true, lastRunAt: new Date().toISOString() });
  let fb = null;
  try {
    const s = await session();
    const cfg = await settings();
    await log(REASON[reason] || 'Bắt đầu share');

    // Bài đã share (theo link + dấu vân tay), danh sách bài chung, caption
    const [done, common, caps] = await Promise.all([
      mySharedSets(s),
      sb('/rest/v1/posts?select=url,fp&hidden=eq.false&order=created_at.desc&limit=200', { token: s.access_token }),
      sb('/rest/v1/captions?select=text', { token: s.access_token }),
    ]);
    const fpOfUrl = Object.fromEntries(common.filter((x) => x.fp).map((x) => [x.url, x.fp]));

    let target = url;
    if (!target) {
      let scanned;
      try { scanned = await scanPages(s, cfg, fb, 20); } catch (e) { fb = e.fb || fb; throw e; }
      fb = scanned.fb;
      Object.assign(fpOfUrl, scanned.fps);
      const candidates = [...scanned.urls, ...common.map((x) => x.url)];
      target = candidates.find((u) => !done.has(u, fpOfUrl[u]));
    }
    if (!target) {
      await log('Không còn bài nào chưa share 🎉');
      await patchState({ lastResult: { ok: true, nothing: true, at: new Date().toISOString() } });
      return { nothing: true };
    }

    const caption = caps.length ? caps[rand(0, caps.length)].text : '';
    await log(`Mở bài: ${target.replace('https://www.facebook.com/', '').slice(0, 60)}…`);
    fb = await openFb(target, fb);

    // Chốt chặn: đọc dấu vân tay trên chính bài -> đã share (dưới link khác) thì bỏ qua, không tim/bình luận/share lại
    const pf = await inTab(fb, fbPostFp, []).catch(() => ({}));
    const targetFp = (pf && pf.fp) || fpOfUrl[target] || null;
    await setPostFp(s, target, targetFp); // bài vừa dán link chưa có dấu vân tay -> bổ sung để web gộp bài trùng
    if (targetFp && done.fps.has(targetFp)) {
      await log('⏭️ Bài này bạn đã share rồi (Facebook đổi link) → bỏ qua');
      await patchState({ lastResult: { ok: true, nothing: true, at: new Date().toISOString() } });
      return { skipped: true };
    }
    // Đưa cửa sổ lên trước: ô caption và nút đăng của FB cần trang đang được focus
    await chrome.windows.update(fb.windowId, { focused: true }).catch(() => {});
    await chrome.tabs.update(fb.tabId, { active: true }).catch(() => {});
    await sleep(1000);

    // Thả cảm xúc + bình luận trước khi share (lỗi ở bước này không chặn việc share)
    if (cfg.react !== 'none' || cfg.comment) {
      let comment = '';
      if (cfg.comment) {
        const rows = await sb('/rest/v1/settings?select=value&key=eq.comments', { token: s.access_token }).catch(() => []);
        const list = ((rows[0] && rows[0].value) || '').split('\n').map((x) => x.trim()).filter(Boolean);
        if (list.length) comment = list[rand(0, list.length)];
        else await log('(Admin chưa soạn danh sách bình luận -> bỏ qua bình luận)');
      }
      const e = await inTab(fb, fbEngage, [cfg.react, comment, false]).catch((err) => ({ notes: [err.message] }));
      const parts = [];
      if (e.reacted === 'love') parts.push('❤️ đã thả tim');
      if (e.reacted === 'like') parts.push('👍 đã thích');
      if (e.reacted === 'skip') parts.push('đã bày tỏ cảm xúc từ trước');
      if (e.commented === 'ok') parts.push(`💬 đã bình luận "${comment}"`);
      if (e.notes && e.notes.length) parts.push(`(${e.notes.join('; ')})`);
      if (parts.length) await log(parts.join(', '));
    }

    const r = await inTab(fb, fbShare, [caption, false]);
    if (!r || !r.ok) throw Object.assign(new Error((r && r.msg) || 'Share thất bại.'), { code: r && r.code });

    await log('✅ Đã share công khai');
    const sharedAt = new Date().toISOString();
    try {
      await sb('/rest/v1/shares', {
        method: 'POST', token: s.access_token, headers: { Prefer: 'return=minimal' },
        body: { user_id: s.user.id, post_url: target, post_fp: r.fp || targetFp, caption, source: 'ext', shared_at: sharedAt },
      });
    } catch (e) {
      // Mất mạng -> lưu lại gửi sau
      const q = await get('pending', []);
      q.push({ user_id: s.user.id, post_url: target, post_fp: r.fp || targetFp, caption, source: 'ext', shared_at: sharedAt });
      await set('pending', q);
      await log(`(Chưa báo lên hệ thống được, sẽ gửi lại: ${e.message})`);
    }
    await patchState({ needFb: null, lastResult: { ok: true, url: target, at: sharedAt } });
    return { ok: true, url: target };
  } catch (e) {
    await log(`❌ ${e.message}`);
    await patchState({
      needFb: ['login', 'checkpoint'].includes(e.code) ? e.code : null,
      lastResult: { ok: false, error: e.message, at: new Date().toISOString() },
    });
    throw e;
  } finally {
    if (fb) chrome.windows.remove(fb.windowId).catch(() => {});
    clearInterval(keepAlive);
    running = false;
    await patchState({ running: false });
  }
}

function fbError(code) {
  if (code === 'login') return 'Chưa đăng nhập Facebook trên Chrome. Mở facebook.com và đăng nhập.';
  if (code === 'checkpoint') return 'Nick Facebook đang bị checkpoint, mở facebook.com để xác minh.';
  return 'Không đọc được page.';
}

async function flushPending() {
  const q = await get('pending', []);
  if (!q.length) return;
  const s = await session();
  await sb('/rest/v1/shares?on_conflict=user_id,post_url,shared_at', {
    method: 'POST', token: s.access_token, headers: { Prefer: 'resolution=ignore-duplicates,return=minimal' }, body: q,
  });
  await set('pending', []);
  await log(`Đã gửi bù ${q.length} lượt share`);
}

// ---------- Lịch tự share ----------
async function lastShareAt(s) {
  const rows = await sb(`/rest/v1/shares?select=shared_at&user_id=eq.${s.user.id}&order=shared_at.desc&limit=1`, { token: s.access_token });
  return rows.length ? new Date(rows[0].shared_at).getTime() : 0;
}

// Tự share định kỳ: N ngày 1 bài (tính từ lần share gần nhất, mọi cách share đều tính)
async function dailyTick(cfg) {
  const today = ymd();
  const st = await get('state', {});
  // Mỗi ngày chọn 1 thời điểm ngẫu nhiên trong 90 phút sau giờ đã đặt
  let plan = st.plan;
  if (!plan || plan.date !== today) {
    plan = { date: today, minute: cfg.hour * 60 + rand(0, 90), attempts: 0 };
    await patchState({ plan });
  }
  const now = new Date();
  if (now.getHours() * 60 + now.getMinutes() < plan.minute || plan.attempts >= 3) return;

  const s = await session();
  const last = await lastShareAt(s);
  // trừ hao 3 tiếng để giờ share không bị trôi dần mỗi kỳ
  if (last && Date.now() - last < cfg.everyDays * 24 * 3600e3 - 3 * 3600e3) return;
  await patchState({ plan: { ...plan, attempts: plan.attempts + 1 } });
  await runJob({ reason: 'daily' });
}

// Tự share bài mới: mỗi 1 tiếng quét page; bài mới xuất hiện ở đầu page -> ~1 tiếng sau thì share
async function newPostTick(cfg, force = false) {
  const now = Date.now();
  const hour = new Date().getHours();
  const st = await get('state', {});
  let seen = await get('seen', null); // { baselineAt, map: { url: thờiĐiểmPhátHiện | 0 (bài cũ/đã xử lý) } }

  if (force || ((!st.lastNewScan || now - st.lastNewScan >= NEW_SCAN_EVERY) && hour >= 7 && hour < 23)) {
    await patchState({ lastNewScan: now });
    const s = await session();
    running = true;
    const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
    await patchState({ running: true });
    let fb = null;
    try {
      const r = await scanPages(s, cfg, null, 4); // chỉ cần vài bài đầu page
      fb = r.fb;
      if (!seen) {
        seen = { baselineAt: now, map: {}, fps: {} };
        r.urls.forEach((u) => { seen.map[u] = 0; if (r.fps[u]) seen.fps[r.fps[u]] = 1; });
        await log(`⚡ Bật tự share bài mới: ghi nhận ${r.urls.length} bài hiện có, từ giờ chỉ share bài page đăng sau thời điểm này.`);
      } else {
        seen.fps = seen.fps || {};
        r.urls.forEach((u, i) => {
          if (u in seen.map) return;
          const fp = r.fps[u];
          // Link mới nhưng cùng nội dung bài cũ (FB đổi link) -> không phải bài mới
          const isNew = i < 3 && !(fp && seen.fps[fp]);
          seen.map[u] = isNew ? now : 0; // bài mới luôn nằm đầu page
          if (fp) seen.fps[fp] = 1;
          if (!isNew) return;
          log(`⚡ Phát hiện bài mới: ${u.replace('https://www.facebook.com/', '').slice(0, 60)}… (sẽ share sau ~1 tiếng)`);
        });
      }
      await set('seen', seen);
    } catch (e) {
      fb = e.fb || fb;
      await log(`❌ Quét bài mới lỗi: ${e.message}`);
      if (['login', 'checkpoint'].includes(e.code)) await patchState({ needFb: e.code });
    } finally {
      if (fb) chrome.windows.remove(fb.windowId).catch(() => {});
      clearInterval(keepAlive);
      running = false;
      await patchState({ running: false });
    }
  }
  if (!seen) return false;

  const due = Object.entries(seen.map).filter(([, t]) => t && now - t >= NEW_POST_DELAY).map(([u]) => u);
  if (!due.length) return false;
  const today = ymd();
  const cnt = st.newCount && st.newCount.date === today ? st.newCount.n : 0;
  if (cnt >= NEW_PER_DAY) return false;

  const s = await session();
  const mine = await mySharedSets(s);
  const url = due.find((u) => !mine.has(u));
  due.forEach((u) => { if (mine.has(u)) seen.map[u] = 0; });
  if (url) seen.map[url] = 0; // mỗi bài chỉ thử 1 lần
  await set('seen', seen);
  if (!url) return false;
  await patchState({ newCount: { date: today, n: cnt + 1 } });
  await runJob({ url, reason: 'new' }).catch(() => {});
  return true;
}

// ---------- Share hàng loạt: lần lượt từng bài, cách nhau 2-4 phút ----------
const QUEUE_MAX = 5;

async function processQueue() {
  const q = await get('queue', null);
  if (!q || !q.active) return;
  if (running) { chrome.alarms.create('queue', { when: Date.now() + 60000 }); return; } // bot đang bận -> thử lại sau 1 phút
  const url = q.items.shift();
  if (!url) { await set('queue', { ...q, active: false, nextAt: null, finishedAt: Date.now() }); return; }
  await set('queue', { ...q, nextAt: null, current: url });
  await log(`📦 Share hàng loạt: bài ${q.done.length + 1}/${q.total}`);

  let stop = false;
  try {
    const r = await runJob({ url, reason: 'queue' });
    q.done.push({ url, ok: true, skipped: !!(r && (r.skipped || r.nothing)) });
  } catch (e) {
    q.done.push({ url, ok: false, msg: e.message });
    stop = ['login', 'checkpoint', 'account'].includes(e.code); // lỗi nick FB -> dừng cả loạt
  }
  const latest = await get('queue', null);
  if (!latest || !latest.active) return; // đã bấm Hủy trong lúc đang share
  if (stop || !q.items.length) {
    await set('queue', { ...q, active: false, current: null, nextAt: null, finishedAt: Date.now(), stopped: stop });
    await log(stop ? '📦 Dừng share hàng loạt vì lỗi nick Facebook' : `📦 Xong share hàng loạt: ${q.done.filter((x) => x.ok && !x.skipped).length}/${q.total} bài`);
    return;
  }
  const nextAt = Date.now() + rand(120, 240) * 1000;
  await set('queue', { ...q, current: null, nextAt });
  chrome.alarms.create('queue', { when: nextAt });
  await log(`📦 Bài tiếp theo lúc ${new Date(nextAt).toLocaleTimeString('vi-VN')}`);
}

async function tick() {
  await flushPending().catch(() => {});
  if (running || !(await get('session', null))) return;
  const q = await get('queue', null);
  if (q && q.active) { if (!q.nextAt || Date.now() > q.nextAt + 60000) processQueue(); return; } // đang share hàng loạt -> tạm hoãn lịch khác
  const cfg = await settings();
  try {
    if (cfg.autoNew && (await newPostTick(cfg))) return;
    if (cfg.auto && !running) await dailyTick(cfg);
  } catch {}
}

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('tick', { periodInMinutes: 10 }));
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('tick', { periodInMinutes: 10 });
  setTimeout(tick, 60000);
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'tick') tick();
  if (a.name === 'queue') processQueue();
});

// ---------- Tin nhắn từ trang web ----------
const handlers = {
  async ping() {
    const s = await get('session', null);
    return { version: VERSION, user: s ? s.user : null };
  },
  async connect({ email, password }) {
    const d = await sb('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
    const s = await saveSession(d);
    await log(`Đã kết nối tài khoản ${s.user.email}`);
    return { user: s.user };
  },
  async disconnect() {
    await chrome.storage.local.remove('session');
    return { ok: true };
  },
  async getState() {
    const s = await get('session', null);
    return {
      version: VERSION, user: s ? s.user : null, settings: await settings(),
      state: { ...(await get('state', {})), running }, queue: await get('queue', null),
    };
  },
  async saveSettings(p) {
    const cfg = { ...(await settings()), ...p };
    cfg.pages = (cfg.pages || []).filter(Boolean);
    cfg.hour = Math.min(22, Math.max(0, +cfg.hour || 9));
    cfg.everyDays = Math.min(7, Math.max(1, +cfg.everyDays || 3));
    cfg.autoNew = !!cfg.autoNew;
    delete cfg.perDay;
    cfg.react = ['love', 'like', 'none'].includes(cfg.react) ? cfg.react : 'love';
    cfg.comment = !!cfg.comment;
    await set('settings', cfg);
    if (cfg.auto) await patchState({ plan: null });
    // Vừa bật tự share bài mới -> ghi nhận các bài hiện có ngay (để không share lại bài cũ)
    if (cfg.autoNew && !(await get('seen', null))) setTimeout(tick, 3000);
    return cfg;
  },
  async runNow({ url } = {}) {
    if (running) throw new Error('Bot đang chạy, đợi xong lượt này.');
    let target = null;
    if (url) {
      target = normalizeUrl(url);
      if (!target) throw new Error('Link không hợp lệ — cần link bài viết facebook.com.');
    }
    runJob({ url: target, reason: target ? 'link' : '' }).catch(() => {});
    return { started: true };
  },
  async queueShare({ urls } = {}) {
    const q = await get('queue', null);
    if (q && q.active) throw new Error('Đang share hàng loạt rồi, đợi xong hoặc bấm Hủy.');
    const items = [...new Set((urls || []).map(normalizeUrl).filter(Boolean))];
    if (!items.length) throw new Error('Chưa chọn bài nào.');
    if (items.length > QUEUE_MAX) throw new Error(`Mỗi lượt tối đa ${QUEUE_MAX} bài.`);
    await set('queue', { active: true, items, total: items.length, done: [], startedAt: Date.now(), nextAt: null });
    await log(`📦 Bắt đầu share hàng loạt ${items.length} bài (mỗi bài cách nhau 2-4 phút)`);
    processQueue().catch(() => {});
    return { started: true, total: items.length };
  },
  async cancelQueue() {
    const q = await get('queue', null);
    if (q && q.active) {
      await set('queue', { ...q, active: false, items: [], nextAt: null, finishedAt: Date.now(), cancelled: true });
      await chrome.alarms.clear('queue');
      await log('📦 Đã hủy share hàng loạt');
    }
    return { ok: true };
  },
  async checkNewNow() {
    if (running) throw new Error('Bot đang chạy, đợi xong lượt này.');
    newPostTick(await settings(), true).catch(() => {});
    return { started: true };
  },
  async clearLog() {
    await patchState({ logs: [] });
    return { ok: true };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const origin = sender.origin || (sender.url && new URL(sender.url).origin);
  const fromPopup = sender.id === chrome.runtime.id && !sender.tab;
  if (!fromPopup && !WEB_ORIGINS.includes(origin)) return;
  const h = handlers[msg && msg.type];
  if (!h) return;
  h(msg.payload || {}).then((result) => sendResponse({ result }), (e) => sendResponse({ error: e.message }));
  return true;
});
